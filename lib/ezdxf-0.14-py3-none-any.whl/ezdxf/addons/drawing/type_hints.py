from typing import Tuple
LayerName = str
Color = str
Radians = float
RGB = Tuple[int, int, int]