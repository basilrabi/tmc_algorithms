# Copyright (c) 2020, Manfred Moitzi
# License: MIT License
# Created: 2020-04-01

from .loader import load, readfile
from .fileheader import FileHeader

